window.onload = () => {
  const tl = gsap.timeline({ defaults: { duration: 1, ease: "power2.inOut" } });

  tl.from(".dancing", { y: -100, opacity: 0 })
    .to(".dancing", { y: 0, repeat: 3, yoyo: true, duration: 0.6 })
    .to(".dancing", {
      opacity: 0,
      duration: 0.5,
      onComplete: () => {
        document.querySelector(".dancing").style.display = "none";
        document.querySelector(".flower").style.display = "block";
      }
    })
    .from(".flower", { opacity: 0, y: 50 })
    .to(".scene", { scale: 0.8, duration: 1, delay: 0.5 })
    .to(".final-message", { opacity: 1, duration: 2 });

  document.getElementById('bg-music').volume = 0.5;
};
